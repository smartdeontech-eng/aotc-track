    document.getElementById('year').textContent = new Date().getFullYear();
    // Live app version from package.json (via /api/version)
    fetch('/api/version').then(r => r.json()).then(d => {
      document.querySelectorAll('.appVersion').forEach(el => { el.textContent = d.version; });
    }).catch(() => { /* non-fatal — placeholders stay as em dashes */ });
    (async () => {
      const currentUser = await requireAuthAndRenderShell('/about.html');
      if (!currentUser) return;
      try {
        const settings = await api('/settings');
        document.getElementById('supportEmail').textContent = settings.email || '—';
      } catch (e) { /* non-fatal — page still works without it */ }
    })();
