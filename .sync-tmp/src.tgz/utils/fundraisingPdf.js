// Announcement PDF for a fundraising day — A4, church letterhead. Four giving
// areas per service (Seed Contributions · Gratitude & Thanksgiving Offering ·
// Day-born Offerings · Chairpersons), then payment methods: the cash
// denomination count, the per-basket breakdown, the cheque register and the
// bank-transfer register, then the grand total.
const PDFDocument = require('pdfkit');
const path = require('path');
const fs = require('fs');
const { toLocalDate } = require('./dates');

const A4 = { width: 595.28, height: 841.89 };
const M = { top: 60, bottom: 60, left: 50, right: 50 };
const USABLE = A4.width - M.left - M.right;
const CREST = path.join(__dirname, '..', 'public', 'img', 'logo.png');
const money = v => 'GHS ' + (Number(v) || 0).toLocaleString(undefined, { minimumFractionDigits: 2 });
// "Sunday, 30 August 2026" — the same form the announcement heads a day with.
const dayLabel = iso => {
  const d = toLocalDate(iso);
  return isNaN(d) ? String(iso || '')
    : d.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
};
// Basket key -> printable name (mirrors the server's catLabel).
function catLabel(key) {
  if (key.startsWith('seed.')) return 'Seed — ' + key.slice(5);
  if (key.startsWith('activity.')) return 'Harvest Week — ' + key.slice(9);
  if (key.startsWith('dayborn.')) return key.slice(8) + '-borns';
  if (key === 'gratitude') return 'Gratitude & Thanksgiving';
  if (key === 'chairpersons') return 'Chairpersons & Co-chairpersons';
  return key;
}

function buildAnnouncementPdf({ event, date, entries, dayborn, seedCategories, activityCategories, denoms }) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margins: M, info: { Title: `${event.name} announcement`, Author: 'AOTC Track' } });
    const chunks = [];
    doc.on('data', c => chunks.push(c));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    // Letterhead
    doc.y = M.top - 10;
    doc.font('Times-Bold').fontSize(14).text('Presbyterian Church of Ghana', M.left, doc.y, { width: USABLE, align: 'center' });
    const crestW = 58;
    const crestY = doc.y + 4;
    try { if (fs.existsSync(CREST)) doc.image(CREST, (A4.width - crestW) / 2, crestY, { fit: [crestW, 66] }); } catch (e) {}
    doc.y = crestY + 70;
    doc.font('Times-Bold').fontSize(11.5).text('Adabraka Official Town Congregation', M.left, doc.y, { width: USABLE, align: 'center' });
    doc.moveDown(0.3);
    doc.moveTo(M.left, doc.y).lineTo(A4.width - M.right, doc.y).lineWidth(1.2).stroke('#1D3F94');
    doc.y += 16;

    doc.font('Times-Bold').fontSize(13).text(`${event.name.toUpperCase()} — FUNDRAISING ANNOUNCEMENT`, M.left, doc.y, { width: USABLE, align: 'center' });
    doc.font('Times-Roman').fontSize(11).text(dayLabel(date), { width: USABLE, align: 'center' });
    doc.moveDown(0.8);

    const services = entries.slice().sort((a, b) => a.service.localeCompare(b.service));
    const cols = services.map(s => s.service === 'joint' ? 'Joint Service' : s.service + ' Service');
    // Day-borns, ordered by the COMBINED total across services — one table can
    // only be in one order. On a dual-service day the two services genuinely
    // rank differently (the 1st may lead with Monday while the 2nd leads with
    // Wednesday), so neither column reads in its own order here and the table
    // must not claim it does. Each service's own ranking is printed beneath the
    // table instead; see rankedLines() below.
    const bornOfSvc = (sv, d) => Number(((sv.categories || {}).dayborn || {})[d]) || 0;
    const rankedDayborn = dayborn.slice().sort((d1, d2) =>
      services.reduce((s, sv) => s + bornOfSvc(sv, d2), 0) -
      services.reduce((s, sv) => s + bornOfSvc(sv, d1), 0));
    // One service's own order, highest first, with the zeros left out — a
    // basket that received nothing was not "last", it simply did not feature.
    const rankedFor = sv => dayborn.slice()
      .map(d => [d, bornOfSvc(sv, d)])
      .filter(([, v]) => v > 0)
      .sort((a, b) => b[1] - a[1]);
    // Seed contributions — this year's sub-categories plus any legacy name that
    // still carries a figure on this day.
    const seedOf = (s, k) => Number(((s.categories || {}).seed || {})[k] || 0);
    const seedKeys = [...new Set([...(seedCategories || []), ...services.flatMap(s => Object.keys((s.categories || {}).seed || {}))])]
      .filter(k => (seedCategories || []).includes(k) || services.some(s => seedOf(s, k) > 0));
    // This year's activities, plus any name that still carries a figure — the
    // same rule the seed block follows, so a renamed activity never silently
    // drops the money it raised.
    const actOf = (e, k) => Number(((e.categories || {}).activities || {})[k]) || 0;
    const actKeys = [...new Set([...(activityCategories || []),
      ...services.flatMap(e => Object.keys((e.categories || {}).activities || {}))])]
      .filter(k => (activityCategories || []).includes(k) || services.some(e => actOf(e, k) > 0));
    // Four areas, each with its own heading: seed money, the harvest-day
    // gratitude offering, the day-born offerings and the chairpersons.
    const blank = services.map(() => '');
    const area = label => ({ cells: [label, ...blank], bold: true, shade: true });
    const line = (label, vals, bold) => ({ cells: [label, ...vals], bold: !!bold });
    const rows = [
      ...(seedKeys.length ? [
        area('SEED CONTRIBUTIONS'),
        ...seedKeys.map(k => line(`   ${k}`, services.map(s => seedOf(s, k)))),
        line('   Seed subtotal', services.map(s => seedKeys.reduce((a, k) => a + seedOf(s, k), 0)), true),
      ] : []),
      { cells: ['GRATITUDE & THANKSGIVING OFFERING', ...services.map(s => s.categories.gratitude)], bold: true, shade: true },
      area(services.length > 1
        ? 'DAY-BORN OFFERINGS  (ordered by the two services together)'
        : 'DAY-BORN OFFERINGS  (ranked highest first)'),
      ...rankedDayborn.map(d => line(`   ${d}-borns`, services.map(s => (s.categories.dayborn || {})[d] || 0))),
      { cells: ['CHAIRPERSONS & CO-CHAIRPERSONS', ...services.map(s => s.categories.chairpersons)], bold: true, shade: true },
      // The week's own activities — shown only when there are any, so a year
      // that ran none prints no empty heading.
      ...(actKeys.length ? [
        area('HARVEST WEEK ACTIVITIES'),
        ...actKeys.map(k => line(`   ${k}`, services.map(s => actOf(s, k)))),
        line('   Activities subtotal', services.map(s => actKeys.reduce((a, k) => a + actOf(s, k), 0)), true),
      ] : []),
    ];
    // The label column is 240, not the 190 it was. Measured in Times-Bold 10pt,
    // the area headings need more than 190 gave them:
    //
    //   GRATITUDE & THANKSGIVING OFFERING          207.9pt
    //   DAY-BORN OFFERINGS  (ranked highest first)  207.7pt
    //   CHAIRPERSONS & CO-CHAIRPERSONS             190.6pt
    //
    // against 180pt of usable width. All three wrapped, and because the row
    // height was a fixed 22 the second line printed below the row's own rule —
    // the struck-through look on the 30 August announcement. 240 gives 230pt,
    // which clears the longest of them. The service columns keep ample room:
    // "202,186.00" is about 55pt in a 127pt column.
    const LABEL_W = 240;
    const colW = (USABLE - LABEL_W) / services.length;
    const pad = 5;
    let y = doc.y;
    const drawRow = (cells, bold, shade) => {
      const widths = [LABEL_W, ...services.map(() => colW)];
      const font = bold ? 'Times-Bold' : 'Times-Roman';
      // The row is as tall as its tallest cell. A fixed height is what clipped
      // the headings, and widening the column alone would only postpone it —
      // a longer seed sub-category name would clip again.
      doc.font(font).fontSize(10);
      const h = Math.max(22, 12 + Math.max(...cells.map((c, i) =>
        doc.heightOfString(String(c), { width: widths[i] - pad * 2 }))));
      // The seed block and the method rows can push a busy day onto a 2nd page.
      if (y + h > A4.height - M.bottom) { doc.addPage(); y = M.top; }
      let x = M.left;
      if (shade) { doc.rect(M.left, y, USABLE, h).fill('#EEF1F7'); doc.fillColor('#000'); }
      cells.forEach((c, i) => {
        doc.rect(x, y, widths[i], h).lineWidth(0.5).stroke('#444');
        doc.font(font).fontSize(10).fillColor('#000')
          .text(String(c), x + pad, y + 6, { width: widths[i] - pad * 2, align: i === 0 ? 'left' : 'right' });
        x += widths[i];
      });
      y += h;
    };
    drawRow(['Category', ...cols], true, true);
    rows.forEach(r => drawRow(
      r.cells.map((v, i) => i === 0 || v === '' ? v : (Number(v) || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })),
      r.bold, r.shade));
    drawRow(['Service Total', ...services.map(s => (s.total || 0).toLocaleString(undefined, { minimumFractionDigits: 2 }))], true, true);
    doc.y = y + 12;

    // Each service's day-borns in ITS OWN order — what is actually read out.
    // The table above cannot show this: it has one row per day shared by both
    // columns, so it is ordered by the two services together.
    const rankLines = services
      .map(sv => [sv, rankedFor(sv)])
      .filter(([, r]) => r.length);
    if (rankLines.length) {
      const needed = 16 + rankLines.length * 30;
      if (doc.y + needed > A4.height - M.bottom) doc.addPage();
      doc.font('Times-Bold').fontSize(10).fillColor('#000')
        .text('Day-born offerings, ranked', M.left, doc.y);
      doc.moveDown(0.2);
      rankLines.forEach(([sv, r]) => {
        const label = sv.service === 'joint' ? 'Joint service' : `${sv.service} service`;
        doc.font('Times-Bold').fontSize(9.5).fillColor('#000')
          .text(label, M.left + 6, doc.y, { width: USABLE - 12 });
        doc.font('Times-Roman').fontSize(9.5)
          .text(r.map(([d, v], i) => `${i + 1}. ${d}-borns ${v.toLocaleString(undefined, { minimumFractionDigits: 2 })}`).join('   ·   '),
            M.left + 6, doc.y + 1, { width: USABLE - 12 });
        doc.moveDown(0.35);
      });
      doc.moveDown(0.3);
    } else {
      doc.y += 4;
    }

    // How it came in — payment methods (only when a breakdown was recorded).
    const hasMethods = services.some(s => s.methods && ((s.methods.cash || 0) + (s.methods.cheque || 0) + (s.methods.momo || 0) + (s.iouTotal || 0) + (s.forexGhs || 0)) > 0);
    if (hasMethods) {
      doc.font('Times-Bold').fontSize(11).text('How it came in (payment methods)', M.left, doc.y);
      doc.moveDown(0.2);
      y = doc.y;
      const mRows = [
        ['Cash', ...services.map(s => (s.methods || {}).cash || 0)],
        ['Cheques', ...services.map(s => (s.methods || {}).cheque || 0)],
        ['Mobile Money', ...services.map(s => (s.methods || {}).momo || 0)],
        ['Bank Transfers', ...services.map(s => (s.methods || {}).transfer || 0)],
        ['IOUs (pledged)', ...services.map(s => s.iouTotal || 0)],
      ];
      drawRow(['Method', ...cols], true, true);
      mRows.forEach(r => drawRow([r[0], ...r.slice(1).map(v => (Number(v) || 0).toLocaleString(undefined, { minimumFractionDigits: 2 }))], false, false));
      drawRow(['GHS subtotal', ...services.map(s => (s.ghsSubtotal || 0).toLocaleString(undefined, { minimumFractionDigits: 2 }))], true, true);
      doc.y = y + 10;

      // A plain bordered table for the registers below (independent of the
      // per-service column layout above).
      // `lineBreak: false` used to be passed here to stop long labels wrapping.
      // It does not work — measured, "Chairpersons & Co-chairpersons" takes two
      // lines either way — so the row is measured and grown instead, which is
      // the only thing that actually keeps text inside its own rules.
      const simple = (widths, tRows, numericCols) => {
        const sp = 4;
        let sy = doc.y;
        tRows.forEach(r => {
          const font = r.bold ? 'Times-Bold' : 'Times-Roman';
          doc.font(font).fontSize(9);
          const h = Math.max(17, 9 + Math.max(...r.cells.map((c, i) =>
            doc.heightOfString(String(c), { width: widths[i] - sp * 2 }))));
          if (sy + h > A4.height - M.bottom) { doc.addPage(); sy = M.top; }
          let x = M.left;
          if (r.shade) { doc.rect(M.left, sy, widths.reduce((a, b) => a + b, 0), h).fill('#EEF1F7'); doc.fillColor('#000'); }
          r.cells.forEach((c, i) => {
            doc.rect(x, sy, widths[i], h).lineWidth(0.5).stroke('#444');
            doc.font(font).fontSize(9).fillColor('#000')
              .text(String(c), x + sp, sy + 4.5, { width: widths[i] - sp * 2, align: i === 0 ? 'left' : (numericCols || i === r.cells.length - 1) ? 'right' : 'left' });
            x += widths[i];
          });
          sy += h;
        });
        doc.y = sy + 10;
      };

      // Cash counting sheet — quantities combined across the day's services.
      const counts = {};
      services.forEach(s => Object.entries(s.cashCount || {}).forEach(([k, q]) => { counts[k] = (counts[k] || 0) + Number(q || 0); }));
      const denomList = denoms || [];
      if (Object.keys(counts).length && denomList.length) {
        if (doc.y > A4.height - M.bottom - 120) doc.addPage();
        doc.font('Times-Bold').fontSize(11).text('Cash counted — denomination breakdown', M.left, doc.y);
        doc.moveDown(0.2);
        const used = denomList.filter(d => counts[d.key]);
        const cashTot = used.reduce((a, d) => a + counts[d.key] * d.value, 0);
        simple([200, 145, 150], [
          { cells: ['Denomination', 'Quantity', 'Amount (GHS)'], bold: true, shade: true },
          ...used.map(d => ({ cells: [d.label, String(counts[d.key]), (counts[d.key] * d.value).toLocaleString(undefined, { minimumFractionDigits: 2 })] })),
          { cells: ['Total cash counted', '', cashTot.toLocaleString(undefined, { minimumFractionDigits: 2 })], bold: true, shade: true },
        ]);
      }

      // Baskets counted on their own
      const money2 = v => (Number(v) || 0).toLocaleString(undefined, { minimumFractionDigits: 2 });
      const bdKeys = [...new Set(services.flatMap(s => Object.keys(s.catMethods || {})))];
      if (bdKeys.length) {
        if (doc.y > A4.height - M.bottom - 120) doc.addPage();
        doc.font('Times-Bold').fontSize(11).text('Breakdown by basket', M.left, doc.y);
        doc.moveDown(0.2);
        const bdGet = (k, f) => services.reduce((a, s) => a + Number((((s.catMethods || {})[k]) || {})[f] || 0), 0);
        // Basket 140: "Chairpersons & Co-chairpersons" is 127.3pt bold at 9pt,
        // and 125 gave it 117. The 15 comes off the numeric columns, which hold
        // "247,536.00" in about 43pt.
        simple([140, 60, 60, 60, 52, 56, 67], [
          { cells: ['Basket', 'Cash', 'Cheques', 'Transfers', 'MoMo', 'Foreign', 'Total'], bold: true, shade: true },
          ...bdKeys.map(k => ({ cells: [catLabel(k), money2(bdGet(k, 'cash')), money2(bdGet(k, 'chequeTotal')), money2(bdGet(k, 'transferTotal')), money2(bdGet(k, 'momo')), money2(bdGet(k, 'forexGhs')), money2(bdGet(k, 'total'))] })),
          { cells: ['Counted baskets total', '', '', '', '', '', money2(bdKeys.reduce((a, k) => a + bdGet(k, 'total'), 0))], bold: true, shade: true },
        ], true);
      }

      // Cheque register
      const allChq = services.flatMap(s => (s.cheques || []).map(c => ({ ...c, service: s.service })));
      if (allChq.length) {
        if (doc.y > A4.height - M.bottom - 100) doc.addPage();
        doc.font('Times-Bold').fontSize(11).text('Cheques received', M.left, doc.y);
        doc.moveDown(0.2);
        // Basket 140, the same as the breakdown table: at 135 the usable width
        // was 127 and the bold label is 127.3 — no margin at all.
        simple([95, 115, 140, 50, 95], [
          { cells: ['Cheque no.', 'Bank', 'Basket', 'Service', 'Amount (GHS)'], bold: true, shade: true },
          ...allChq.map(c => ({ cells: [c.number || '—', c.bank || '—', c.category || 'service level', c.service, money2(c.amount)] })),
          { cells: ['Total', '', '', '', money2(allChq.reduce((a, c) => a + (Number(c.amount) || 0), 0))], bold: true, shade: true },
        ]);
      }

      // Bank transfer register
      const allTrf = services.flatMap(s => (s.transfers || []).map(t => ({ ...t, service: s.service })));
      if (allTrf.length) {
        if (doc.y > A4.height - M.bottom - 100) doc.addPage();
        doc.font('Times-Bold').fontSize(11).text('Bank transfers received', M.left, doc.y);
        doc.moveDown(0.2);
        simple([105, 100, 140, 55, 95], [
          { cells: ['Bank', 'Reference', 'Basket', 'Service', 'Amount (GHS)'], bold: true, shade: true },
          ...allTrf.map(t => ({ cells: [t.bank || '—', t.reference || '—', t.category || 'service level', t.service, money2(t.amount)] })),
          { cells: ['Total', '', '', '', money2(allTrf.reduce((a, t) => a + (Number(t.amount) || 0), 0))], bold: true, shade: true },
        ]);
      }
      y = doc.y;

      // Foreign currency listed separately, then the all-in-GHS figure.
      const allForex = services.flatMap(s => (s.forex || []).map(f => ({ ...f, service: s.service })));
      if (allForex.length) {
        doc.moveDown(0.4);
        doc.font('Times-Bold').fontSize(11).text('Foreign currency (converted at the day’s rates)', M.left, doc.y);
        doc.moveDown(0.2);
        const byCur = {};
        allForex.forEach(f => {
          byCur[f.currency] = byCur[f.currency] || { amount: 0, ghs: 0, rate: f.rate };
          byCur[f.currency].amount += f.amount; byCur[f.currency].ghs += f.ghs; byCur[f.currency].rate = f.rate;
        });
        Object.entries(byCur).forEach(([cur, v]) => {
          doc.font('Times-Roman').fontSize(10.5).text(
            `${cur} ${v.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}  @ ${v.rate}  =  ${money(v.ghs)}`,
            M.left + 10, doc.y);
        });
        const ghsSub = services.reduce((s2, s) => s2 + (s.ghsSubtotal || 0), 0);
        const fxGhs = services.reduce((s2, s) => s2 + (s.forexGhs || 0), 0);
        doc.moveDown(0.4);
        doc.font('Times-Bold').fontSize(10.5).text(`GHS subtotal: ${money(ghsSub)}   +   Forex (GHS equivalent): ${money(fxGhs)}`, M.left, doc.y);
      }
      doc.moveDown(0.8);
    }

    // ---- What the day itself brought, then the seed -----------------------
    // The congregation asks about the Sunday: the Gratitude offering, the
    // day-born baskets and the Chairpersons. Seed contributions are pledged at
    // the launch and merely booked against the day, so a single grand total
    // buries the thing everybody wants to know. The three are added on their
    // own first, and the seed joins only at the last line.
    //
    // Broken out BY SERVICE, like every other table in this document — on a
    // dual-service day the 1st and the 2nd are what the Session compares, and a
    // combined-only summary hides it.
    const gratOf = e => Number((e.categories || {}).gratitude) || 0;
    const bornOf = e => Object.values(((e.categories || {}).dayborn) || {}).reduce((a, v) => a + (Number(v) || 0), 0);
    const chairOf = e => Number((e.categories || {}).chairpersons) || 0;
    const seedOf2 = e => Object.values(((e.categories || {}).seed) || {}).reduce((a, v) => a + (Number(v) || 0), 0);
    const dayOf = e => gratOf(e) + bornOf(e) + chairOf(e);
    const sumAcross = f => services.reduce((a, e) => a + f(e), 0);
    const grand = services.reduce((s2, e) => s2 + (e.total || 0), 0);

    const closing = [
      { label: 'Gratitude & Thanksgiving Offering', of: gratOf },
      { label: 'Day-born Offerings', of: bornOf },
      { label: 'Chairpersons & Co-chairpersons', of: chairOf },
      { label: 'THE DAY’S OFFERINGS', of: dayOf, bold: true, rule: true },
      { label: 'Seed Contributions', of: seedOf2 },
    ];
    // The week's activities are neither the Sunday offering nor the seed, so
    // they get a line of their own — after the day, before the seed.
    const actTotalOf = e => Object.values(((e.categories || {}).activities) || {})
      .reduce((a, v) => a + (Number(v) || 0), 0);
    if (services.some(e => actTotalOf(e) > 0)) {
      closing.splice(4, 0, { label: 'Harvest Week Activities', of: actTotalOf });
    }

    // One column per service, plus a Total column when there is more than one —
    // on a joint day a "Total" beside a single figure says nothing.
    const multi = services.length > 1;
    // Measured: the longest label is 167.9pt in Times-Bold 11 and the widest
    // realistic figure 57.8pt, so 200 for the label and 98 a column fits 495.
    const LBL_W = multi ? 200 : 260;
    const NUM_W = multi ? Math.min(98, (USABLE - LBL_W) / (services.length + 1)) : 120;
    const sumCols = multi ? [...services.map(e => e.service === 'joint' ? 'Joint' : e.service + ' Service'), 'Total'] : ['Amount'];
    const tblW = LBL_W + sumCols.length * NUM_W;
    const tx = i => M.left + (USABLE - tblW) / 2 + LBL_W + i * NUM_W;
    const lblX = M.left + (USABLE - tblW) / 2;

    // Keep the summary, the grand total, the target and the verse together —
    // they were falling apart across a page break, leaving a nearly empty last
    // page with the target line and the verse stranded on it.
    const closingH = 22 + closing.length * 18 + 34 + (event.target ? 20 : 0) + 60;
    if (doc.y + closingH > A4.height - M.bottom) doc.addPage();

    doc.moveDown(0.3);
    // Column headings.
    let cy = doc.y;
    doc.font('Times-Bold').fontSize(9.5).fillColor('#000');
    sumCols.forEach((c, i) => doc.text(c, tx(i), cy, { width: NUM_W - 6, align: 'right' }));
    cy += 13;
    doc.moveTo(lblX, cy - 2).lineTo(lblX + tblW, cy - 2).lineWidth(0.6).stroke('#444');
    cy += 2;

    closing.forEach(r => {
      const vals = multi ? [...services.map(e => r.of(e)), sumAcross(r.of)] : [sumAcross(r.of)];
      doc.font(r.bold ? 'Times-Bold' : 'Times-Roman').fontSize(11).fillColor('#000');
      doc.text(r.label, lblX, cy, { width: LBL_W - 8 });
      vals.forEach((v, i) => doc.font(r.bold ? 'Times-Bold' : 'Times-Roman').fontSize(11)
        .text((Number(v) || 0).toLocaleString(undefined, { minimumFractionDigits: 2 }),
          tx(i), cy, { width: NUM_W - 6, align: 'right' }));
      cy += 16;
      if (r.rule) {
        doc.moveTo(lblX, cy - 3).lineTo(lblX + tblW, cy - 3).lineWidth(0.6).stroke('#444');
        cy += 3;
      }
    });
    // The service totals — what each service brought in altogether.
    doc.moveTo(lblX, cy).lineTo(lblX + tblW, cy).lineWidth(1).stroke('#000');
    cy += 4;
    doc.font('Times-Bold').fontSize(11).fillColor('#000');
    doc.text(multi ? 'SERVICE TOTAL' : 'TOTAL', lblX, cy, { width: LBL_W - 8 });
    (multi ? [...services.map(e => e.total || 0), grand] : [grand]).forEach((v, i) =>
      doc.font('Times-Bold').fontSize(11)
        .text((Number(v) || 0).toLocaleString(undefined, { minimumFractionDigits: 2 }),
          tx(i), cy, { width: NUM_W - 6, align: 'right' }));
    cy += 20;
    doc.y = cy;

    doc.font('Times-Bold').fontSize(13).text(`GRAND TOTAL (all in GHS): ${money(grand)}`, M.left, doc.y, { width: USABLE, align: 'center' });
    if (event.target) {
      doc.moveDown(0.4);
      doc.font('Times-Roman').fontSize(10.5)
        .text(`Event target: ${money(event.target)} · Achieved so far counts toward the target.`, M.left, doc.y, { width: USABLE, align: 'center' });
    }
    doc.moveDown(1.2);
    doc.font('Times-Roman').fontSize(10.5).text('“Each of you should give what you have decided in your heart to give, not reluctantly or under compulsion, for God loves a cheerful giver.” — 2 Corinthians 9:7', M.left, doc.y, { width: USABLE, align: 'center' });
    doc.end();
  });
}

// ---- The counting sheet ----------------------------------------------------
// A paper pro-forma for the counting team, filled in on the day BEFORE anything
// is typed. It mirrors the entry form basket for basket and method for method,
// so transcription is mechanical: every box on paper has exactly one box on
// screen. Where the two drift, the transcription starts needing judgement,
// which is where errors come from — so this is generated from the same
// `seedCategories` and `DENOMS` the form is built from, never hand-maintained.
//
// Three pages, because a counting team works in three passes:
//   1. the basket grid — what each basket holds, by method
//   2. the denomination count — one sheet per basket counted note by note
//   3. the registers — cheques, transfers, pledges, foreign notes
function buildCountingSheetPdf({ event, date, dayborn, seedCategories, activityCategories, denoms, services }) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margins: M, bufferPages: true,
      info: { Title: `${event ? event.name : 'Fundraising'} counting sheet`, Author: 'AOTC Track' } });
    const chunks = [];
    doc.on('data', c => chunks.push(c));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    const svc = (services && services.length ? services : ['1st', '2nd']);
    // Hand-filled boxes need room. 26pt is what a written figure and a set of
    // initials actually take; the printed reports use 17–22.
    const RH = 26;
    const rule = (x1, y1, x2, y2, w) => doc.moveTo(x1, y1).lineTo(x2, y2).lineWidth(w || 0.6).stroke('#444');

    const letterhead = (sub) => {
      doc.y = M.top - 20;
      doc.font('Times-Bold').fontSize(13).fillColor('#000')
        .text('Presbyterian Church of Ghana', M.left, doc.y, { width: USABLE, align: 'center' });
      doc.font('Times-Bold').fontSize(10.5)
        .text('Adabraka Official Town Congregation', M.left, doc.y + 1, { width: USABLE, align: 'center' });
      doc.moveDown(0.3);
      doc.font('Times-Bold').fontSize(12.5)
        .text('COUNTING SHEET', M.left, doc.y, { width: USABLE, align: 'center' });
      doc.font('Times-Roman').fontSize(9.5)
        .text('To be completed by hand on the day, then entered into AOTC Track. Do not enter anything not written here.',
          M.left, doc.y + 2, { width: USABLE, align: 'center' });
      if (sub) {
        doc.font('Times-Bold').fontSize(10.5).text(sub, M.left, doc.y + 4, { width: USABLE, align: 'center' });
      }
      doc.moveDown(0.6);
    };
    // Pages get separated on a counting table, so each one has to say what it
    // is and who wrote it.
    const footer = (what) => {
      // The footer sits INSIDE the bottom margin, and pdfkit adds a page the
      // moment text would cross that line — which turned a three-page sheet
      // into ten. Drop the margin for the two writes, then put it back.
      const keep = doc.page.margins.bottom;
      const savedY = doc.y;
      doc.page.margins.bottom = 0;
      const fy = A4.height - keep + 16;
      doc.font('Times-Roman').fontSize(8).fillColor('#555');
      doc.text(`${what}${date ? ' · ' + date : ''}`, M.left, fy, { width: 300, lineBreak: false });
      doc.text('Counter’s initials', M.left + 330, fy, { width: 80, lineBreak: false });
      doc.moveTo(M.left + 400, fy + 9).lineTo(M.left + 495, fy + 9).lineWidth(0.5).stroke('#888');
      doc.fillColor('#000');
      doc.page.margins.bottom = keep;
      doc.y = savedY;
    };

    // A labelled blank the team writes into.
    const blanks = (items, y) => {
      let x = M.left;
      items.forEach(([label, w]) => {
        doc.font('Times-Roman').fontSize(9.5).fillColor('#000').text(label, x, y, { width: w, lineBreak: false });
        const lx = x + doc.widthOfString(label) + 3;
        rule(lx, y + 11, x + w - 6, y + 11);
        x += w;
      });
      return y + 22;
    };

    // ---- Page 1: the basket grid ----
    letterhead(`${event ? event.name : ''}${event && date ? ' — ' : ''}${date ? dayLabel(date) : ''}`);
    let y = doc.y;
    y = blanks([['Event:', 150], ['Date:', 130], ['Service (1st / 2nd / Joint):', 215]], y);
    y = blanks([['Counted by:', 165], ['and:', 165], ['Witnessed by:', 165]], y) + 2;

    // Columns: the basket, then one column per method, then the total. These are
    // exactly the boxes the entry form has for a basket breakdown.
    // 495 exactly, which is the usable width — the first cut came to 516 and ran
    // past the right margin. Basket is 150 because the longest label,
    // "   Chairpersons & Co-chairpersons", measures 131.7pt in Times-Roman 9.5
    // and 132 gave it 124. Same fault, same lesson as the announcement.
    const COLS = [
      ['Basket', 150, 'left'],
      ['Cash', 52, 'right'],
      ['MoMo', 46, 'right'],
      ['Cheques', 52, 'right'],
      ['Transfer', 50, 'right'],
      ['Foreign', 46, 'right'],
      ['Pledges', 46, 'right'],
      ['TOTAL', 53, 'right'],
    ];
    const gridW = COLS.reduce((a, c) => a + c[1], 0);
    const cx = i => M.left + COLS.slice(0, i).reduce((a, c) => a + c[1], 0);

    const gridRow = (label, opts = {}) => {
      // The row grows to hold its label. A fixed height is what clipped
      // "CHAIRPERSONS & CO-CHAIRPERSONS" in the announcement, and this sheet
      // repeated it until it was rendered and looked at.
      doc.font(opts.bold ? 'Times-Bold' : 'Times-Roman').fontSize(9.5);
      const need = doc.heightOfString(String(label), { width: COLS[0][1] - 8 }) + 14;
      const h = opts.head ? 20 : Math.max(RH, need);
      if (y + h > A4.height - M.bottom) { doc.addPage(); letterhead(''); y = doc.y; }
      if (opts.shade) { doc.rect(M.left, y, gridW, h).fill('#EEF1F7'); doc.fillColor('#000'); }
      COLS.forEach((c, i) => {
        doc.rect(cx(i), y, c[1], h).lineWidth(0.6).stroke('#444');
        const txt = i === 0 ? label : (opts.head ? c[0] : '');
        if (txt) {
          doc.font(opts.head || opts.bold ? 'Times-Bold' : 'Times-Roman').fontSize(opts.head ? 9 : 9.5).fillColor('#000')
            .text(String(txt), cx(i) + 4, y + (opts.head ? 6 : 8),
              { width: c[1] - 8, align: i === 0 ? 'left' : c[2] });
        }
        if (opts.head && i > 0) {
          doc.font('Times-Bold').fontSize(9).text(c[0], cx(i) + 4, y + 6, { width: c[1] - 8, align: 'right' });
        }
      });
      y += h;
    };
    // The heading row, drawn once.
    if (y + 20 > A4.height - M.bottom) { doc.addPage(); letterhead(''); y = doc.y; }
    doc.rect(M.left, y, gridW, 20).fill('#EEF1F7'); doc.fillColor('#000');
    COLS.forEach((c, i) => {
      doc.rect(cx(i), y, c[1], 20).lineWidth(0.6).stroke('#444');
      doc.font('Times-Bold').fontSize(9).fillColor('#000')
        .text(c[0], cx(i) + 4, y + 6, { width: c[1] - 8, align: i === 0 ? 'left' : 'right' });
    });
    y += 20;

    const area = t => {
      if (y + 18 > A4.height - M.bottom) { doc.addPage(); letterhead(''); y = doc.y; }
      doc.rect(M.left, y, gridW, 18).fill('#DDE3F0'); doc.fillColor('#000');
      doc.rect(M.left, y, gridW, 18).lineWidth(0.6).stroke('#444');
      doc.font('Times-Bold').fontSize(9).text(t, M.left + 4, y + 5, { width: gridW - 8 });
      y += 18;
    };

    area('SEED CONTRIBUTIONS');
    (seedCategories || []).forEach(k => gridRow('   ' + k));
    area('GRATITUDE & THANKSGIVING OFFERING');
    gridRow('   Gratitude & Thanksgiving');
    area('DAY-BORN OFFERINGS');
    (dayborn || []).forEach(d => gridRow('   ' + d + '-borns'));
    area('CHAIRPERSONS & CO-CHAIRPERSONS');
    gridRow('   Chairpersons & Co-chairpersons');
    if ((activityCategories || []).length) {
      area('HARVEST WEEK ACTIVITIES');
      (activityCategories || []).forEach(a => gridRow('   ' + a));
    }
    area('NOT ATTRIBUTED TO A BASKET  (entered on the service panel)');
    gridRow('   Service level');
    gridRow('GRAND TOTAL', { bold: true, shade: true });

    // The reconciliation the app will enforce at submit, done here first on
    // paper — which is the whole point of a counting sheet.
    y += 10;
    // 84, not 56: line B wraps to two lines and was printing over the sentence
    // beneath it. Measured rather than guessed at.
    const BOXH = 84;
    if (y + BOXH + 20 > A4.height - M.bottom) { doc.addPage(); letterhead(''); y = doc.y; }
    doc.font('Times-Bold').fontSize(10).fillColor('#000').text('Check before entering', M.left, y);
    y += 14;
    doc.rect(M.left, y, gridW, BOXH).lineWidth(0.6).stroke('#444');
    doc.font('Times-Roman').fontSize(9.5);
    doc.text('A.  Baskets added down the TOTAL column', M.left + 8, y + 9, { width: 290 });
    rule(M.left + 305, y + 20, M.left + gridW - 12, y + 20);
    doc.text('B.  Methods added across', M.left + 8, y + 30, { width: 290 });
    doc.font('Times-Roman').fontSize(8.5)
      .text('(cash + MoMo + cheques + transfers + foreign + pledges)', M.left + 20, y + 41, { width: 270 });
    rule(M.left + 305, y + 41, M.left + gridW - 12, y + 41);
    doc.font('Times-Bold').fontSize(9.5).text('A and B must be the same figure. If they are not, count again before typing.',
      M.left + 8, y + 60, { width: gridW - 16 });
    y += BOXH + 12;

    footer('Counting sheet — baskets');

    // ---- Page 2: the denomination count ----
    doc.addPage();
    letterhead('CASH COUNTED — one sheet per basket counted note by note');
    y = doc.y;
    y = blanks([['Basket:', 260], ['Service:', 120], ['Counted by:', 115]], y) + 4;
    const DC = [['Denomination', 150], ['Quantity', 78], ['Amount (GHS)', 100]];
    const dcW = DC.reduce((a, c) => a + c[1], 0);
    const dcx = i => M.left + DC.slice(0, i).reduce((a, c) => a + c[1], 0);
    const dRow = (cells, opts = {}) => {
      const h = opts.head ? 19 : 22;
      if (y + h > A4.height - M.bottom) { doc.addPage(); letterhead('CASH COUNTED (continued)'); y = doc.y; }
      if (opts.shade) { doc.rect(M.left, y, dcW, h).fill('#EEF1F7'); doc.fillColor('#000'); }
      DC.forEach((c, i) => {
        doc.rect(dcx(i), y, c[1], h).lineWidth(0.6).stroke('#444');
        if (cells[i]) {
          doc.font(opts.head || opts.bold ? 'Times-Bold' : 'Times-Roman').fontSize(9.5).fillColor('#000')
            .text(String(cells[i]), dcx(i) + 4, y + (opts.head ? 5 : 7), { width: c[1] - 8, align: i === 0 ? 'left' : 'right' });
        }
      });
      y += h;
    };
    dRow(DC.map(c => c[0]), { head: true, shade: true });
    const notes = (denoms || []).filter(d => d.kind !== 'coin');
    const coins = (denoms || []).filter(d => d.kind === 'coin');
    notes.forEach(d => dRow([d.label, '', '']));
    if (coins.length) {
      dRow(['COINS', '', ''], { bold: true, shade: true });
      coins.forEach(d => dRow([d.label, '', '']));
    }
    dRow(['TOTAL CASH COUNTED', '', ''], { bold: true, shade: true });
    doc.font('Times-Roman').fontSize(9).text(
      'Quantity × face value = amount. The total here must equal the Cash box for this basket on page 1.',
      M.left, y + 6, { width: dcW });

    footer('Counting sheet — cash counted');

    // ---- Page 3: the registers ----
    doc.addPage();
    letterhead('REGISTERS — every cheque, transfer, pledge and foreign note');
    y = doc.y;
    const reg = (title, cols, rows, note) => {
      if (y + 40 + rows * 22 > A4.height - M.bottom) { doc.addPage(); letterhead('REGISTERS (continued)'); y = doc.y; }
      doc.font('Times-Bold').fontSize(10.5).fillColor('#000').text(title, M.left, y);
      y += 14;
      const w = cols.reduce((a, c) => a + c[1], 0);
      const rx = i => M.left + cols.slice(0, i).reduce((a, c) => a + c[1], 0);
      doc.rect(M.left, y, w, 19).fill('#EEF1F7'); doc.fillColor('#000');
      cols.forEach((c, i) => {
        doc.rect(rx(i), y, c[1], 19).lineWidth(0.6).stroke('#444');
        doc.font('Times-Bold').fontSize(9).text(c[0], rx(i) + 4, y + 5, { width: c[1] - 8 });
      });
      y += 19;
      for (let r = 0; r < rows; r += 1) {
        cols.forEach((c, i) => { doc.rect(rx(i), y, c[1], 22).lineWidth(0.6).stroke('#444'); });
        y += 22;
      }
      if (note) {
        doc.font('Times-Roman').fontSize(8.5).fillColor('#000').text(note, M.left, y + 3, { width: w });
        y += 14;
      }
      y += 8;
    };
    reg('Cheques received', [['Cheque no.', 90], ['Bank', 105], ['Which basket', 135], ['Svc', 40], ['Amount (GHS)', 95]], 7,
      'The cheque number is required in the app. A cheque with no number cannot be entered.');
    reg('Bank transfers', [['Bank', 105], ['Reference', 120], ['Which basket', 135], ['Svc', 40], ['Amount (GHS)', 65]], 5,
      'The bank is required in the app.');
    reg('Pledges (IOUs)', [['Name', 130], ['Contact', 100], ['Which basket', 110], ['Amount', 70], ['Promised by (date)', 85]], 6,
      'A promised date is required — it drives the reminders. A pledge counts toward the basket it was made in.');
    reg('Foreign currency', [['Currency', 70], ['Amount', 80], ['Rate for the day', 100], ['Which basket', 145], ['GHS', 100]], 4,
      'One rate per currency for the WHOLE day — agree it once and write it here. The app refuses a foreign note whose currency has no rate.');

    footer('Counting sheet — registers and sign-off');
    signOff();
    doc.end();

    // ---- Sign-off --------------------------------------------------------
    // The same chain the app enforces — counted, checked by the Harvest
    // Committee, entered, verified by the Accounts Clerk, approved by the
    // Treasurer — so the paper and the system tell one story. A sheet signed by
    // nobody is a note; this is the record the entry is made from, and it is
    // what the Treasurer holds against the figures if they are ever queried.
    function signOff() {
      const ROWS = [
        ['Counted by', 'Name and signature of the first counter'],
        ['Counted by', 'Name and signature of the second counter'],
        ['Checked by', 'Harvest Committee — the sheet adds up and A = B'],
        ['Entered by', 'Typed into AOTC Track from this sheet'],
        ['Verified by', 'Accounts Clerk — after entry (verifies in the app)'],
        ['Approved by', 'Treasurer — approves and locks the figures'],
      ];
      const H = 34;
      const W = [96, 190, 118, 91];        // 495
      if (doc.y + 30 + ROWS.length * H > A4.height - M.bottom) doc.addPage();
      let yy = Math.max(y, doc.y) + 6;
      doc.font('Times-Bold').fontSize(11).fillColor('#000').text('SIGN-OFF', M.left, yy);
      doc.font('Times-Roman').fontSize(8.5)
        .text('No figure is entered into AOTC Track from an unsigned sheet. Keep this sheet with the day’s records.',
          M.left, yy + 13, { width: 495 });
      yy += 28;
      const xs = i => M.left + W.slice(0, i).reduce((a, b) => a + b, 0);
      const head = ['Role', 'Name', 'Signature', 'Date'];
      doc.rect(M.left, yy, 495, 18).fill('#EEF1F7'); doc.fillColor('#000');
      head.forEach((h, i) => {
        doc.rect(xs(i), yy, W[i], 18).lineWidth(0.6).stroke('#444');
        doc.font('Times-Bold').fontSize(9).text(h, xs(i) + 4, yy + 5, { width: W[i] - 8 });
      });
      yy += 18;
      ROWS.forEach(([role, hint]) => {
        W.forEach((w, i) => { doc.rect(xs(i), yy, w, H).lineWidth(0.6).stroke('#444'); });
        doc.font('Times-Bold').fontSize(9).fillColor('#000').text(role, xs(0) + 4, yy + 5, { width: W[0] - 8 });
        doc.font('Times-Roman').fontSize(7.5).fillColor('#555')
          .text(hint, xs(0) + 4, yy + 17, { width: W[0] - 8 });
        doc.fillColor('#000');
        yy += H;
      });
      y = yy;
    }
  });
}

// Year statement: the Harvest Committee's account to Session — per-event
// inflows (by day), outflows, and net proceeds, with targets.
function buildStatementPdf({ year, events, entries, expenses, ious, annualTarget, seedCategories, activityCategories }) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margins: M, bufferPages: true, info: { Title: `Fundraising statement ${year}`, Author: 'AOTC Track' } });
    const chunks = [];
    doc.on('data', c => chunks.push(c));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    doc.y = M.top - 10;
    doc.font('Times-Bold').fontSize(14).text('Presbyterian Church of Ghana', M.left, doc.y, { width: USABLE, align: 'center' });
    const crestW = 58;
    const crestY = doc.y + 4;
    try { if (fs.existsSync(CREST)) doc.image(CREST, (A4.width - crestW) / 2, crestY, { fit: [crestW, 66] }); } catch (e) {}
    doc.y = crestY + 70;
    doc.font('Times-Bold').fontSize(11.5).text('Adabraka Official Town Congregation', M.left, doc.y, { width: USABLE, align: 'center' });
    doc.moveDown(0.3);
    doc.moveTo(M.left, doc.y).lineTo(A4.width - M.right, doc.y).lineWidth(1.2).stroke('#1D3F94');
    doc.y += 16;
    doc.font('Times-Bold').fontSize(13).text(`HARVEST & FUNDRAISING STATEMENT — ${year}`, M.left, doc.y, { width: USABLE, align: 'center' });
    doc.moveDown(0.8);

    const pad = 5, rowH = 20;
    function tableRows(widths, rows, opts = {}) {
      rows.forEach(r => {
        if (doc.y + rowH > A4.height - M.bottom) doc.addPage();
        // .text() advances doc.y, so pin every cell of the row to rowY and
        // only move down once per row — otherwise the cells staircase.
        const rowY = doc.y;
        let x = M.left;
        if (r.shade) { doc.rect(M.left, rowY, widths.reduce((a, b) => a + b, 0), rowH).fill('#EEF1F7'); doc.fillColor('#000'); }
        r.cells.forEach((c, i) => {
          doc.rect(x, rowY, widths[i], rowH).lineWidth(0.5).stroke('#444');
          doc.font(r.bold ? 'Times-Bold' : 'Times-Roman').fontSize(9.5).fillColor('#000')
            .text(String(c), x + pad, rowY + 5, { width: widths[i] - pad * 2, align: i === 0 ? 'left' : 'right', lineBreak: false });
          x += widths[i];
        });
        doc.y = rowY + rowH;
      });
      doc.y += 10;
    }

    // Summary table
    doc.font('Times-Bold').fontSize(11).text('Summary by Event', M.left);
    doc.moveDown(0.2);
    const w1 = [150, 90, 90, 85, 80];
    tableRows(w1, [
      { cells: ['Event', 'Target', 'Raised', 'Expenses', 'Net'], bold: true, shade: true },
      ...events.map(ev => ({ cells: [ev.name, ev.target ? money(ev.target) : '—', money(ev.raised), money(ev.spent), money(ev.net)] })),
      { cells: ['TOTAL', annualTarget ? money(annualTarget) : '—',
        money(events.reduce((s2, e) => s2 + e.raised, 0)), money(events.reduce((s2, e) => s2 + e.spent, 0)),
        money(events.reduce((s2, e) => s2 + e.net, 0))], bold: true, shade: true },
    ]);

    // Seed contributions for the year, by the body that gave them
    const seedOf = (e, k) => Number(((e.categories || {}).seed || {})[k] || 0);
    const seedKeys = [...new Set([...(seedCategories || []), ...entries.flatMap(e => Object.keys((e.categories || {}).seed || {}))])];
    const seedTotals = seedKeys
      .map(k => [k, entries.reduce((s2, e) => s2 + seedOf(e, k), 0)])
      .filter(([k, v]) => v > 0 || (seedCategories || []).includes(k));
    if (seedTotals.length) {
      doc.font('Times-Bold').fontSize(11).text('Seed contributions', M.left);
      doc.moveDown(0.2);
      tableRows([250, 245], [
        { cells: ['Given by', 'Amount'], bold: true, shade: true },
        ...seedTotals.map(([k, v]) => ({ cells: [k, money(v)] })),
        { cells: ['TOTAL SEED', money(seedTotals.reduce((s2, x) => s2 + x[1], 0))], bold: true, shade: true },
      ]);
    }

    // The week's activities across the year, by activity — so the committee can
    // see which of them actually raised money and plan the next programme.
    const actOf2 = (e, k) => Number(((e.categories || {}).activities || {})[k] || 0);
    const actKeys2 = [...new Set([...(activityCategories || []),
      ...entries.flatMap(e => Object.keys((e.categories || {}).activities || {}))])];
    const actTotals = actKeys2
      .map(k => [k, entries.reduce((s2, e) => s2 + actOf2(e, k), 0)])
      .filter(([k, v]) => v > 0 || (activityCategories || []).includes(k));
    if (actTotals.length) {
      doc.font('Times-Bold').fontSize(11).text('Harvest week activities', M.left);
      doc.moveDown(0.2);
      tableRows([250, 245], [
        { cells: ['Activity', 'Amount'], bold: true, shade: true },
        ...actTotals.map(([k, v]) => ({ cells: [k, money(v)] })),
        { cells: ['TOTAL ACTIVITIES', money(actTotals.reduce((s2, x) => s2 + x[1], 0))], bold: true, shade: true },
      ]);
    }

    // How it came in — payment methods across the whole year
    const mt = { cash: 0, cheque: 0, momo: 0, transfer: 0, iou: 0, forex: 0 };
    entries.forEach(e => {
      const m = e.methods || {};
      mt.cash += Number(m.cash) || 0;
      mt.cheque += Number(m.cheque) || 0;
      mt.momo += Number(m.momo) || 0;
      mt.transfer += Number(m.transfer) || 0;
      mt.iou += Number(e.iouTotal) || 0;
      mt.forex += Number(e.forexGhs) || 0;
    });
    const mSum = Object.values(mt).reduce((a, b) => a + b, 0);
    if (mSum > 0) {
      doc.font('Times-Bold').fontSize(11).text('How it came in (year)', M.left);
      doc.moveDown(0.2);
      tableRows([250, 245], [
        { cells: ['Method', 'Amount'], bold: true, shade: true },
        { cells: ['Cash', money(mt.cash)] },
        { cells: ['Cheques', money(mt.cheque)] },
        { cells: ['Mobile Money', money(mt.momo)] },
        { cells: ['Bank Transfers', money(mt.transfer)] },
        { cells: ['IOUs (pledged)', money(mt.iou)] },
        { cells: ['Foreign currency (GHS equivalent)', money(mt.forex)] },
        { cells: ['TOTAL', money(mSum)], bold: true, shade: true },
      ]);
    }

    // Inflow detail
    if (entries.length) {
      doc.font('Times-Bold').fontSize(11).text('Inflows (by fundraising day)', M.left);
      doc.moveDown(0.2);
      const w2 = [140, 100, 80, 175];
      tableRows(w2, [
        { cells: ['Event', 'Date', 'Service', 'Amount'], bold: true, shade: true },
        ...entries.slice().sort((a, b) => a.date.localeCompare(b.date)).map(e => ({
          cells: [e.eventName, toLocalDate(e.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }), e.service, money(e.total)],
        })),
      ]);
    }

    // IOU register — outstanding pledges first, then redeemed
    if ((ious || []).length) {
      doc.font('Times-Bold').fontSize(11).text('IOU register (pledges)', M.left);
      doc.moveDown(0.2);
      const w4 = [105, 95, 80, 65, 70, 80];
      const sorted = ious.slice().sort((a, b) => (a.status === b.status ? (a.dueDate || '').localeCompare(b.dueDate || '') : a.status === 'paid' ? 1 : -1));
      tableRows(w4, [
        { cells: ['Name', 'Basket', 'Amount', 'Due date', 'Status', 'Event / day'], bold: true, shade: true },
        ...sorted.map(i => ({ cells: [
          i.name, i.category || 'service level', money(i.amount),
          i.dueDate ? toLocalDate(i.dueDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }) : '—',
          i.status === 'paid' ? 'PAID' : (i.dueDate && i.dueDate < new Date().toISOString().slice(0, 10) ? 'OVERDUE' : 'Outstanding'),
          `${i.eventName} ${toLocalDate(i.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}`,
        ] })),
        { cells: ['Outstanding total', '', money(ious.filter(i => i.status !== 'paid').reduce((s, i) => s + (i.amount || 0), 0)), '', '', ''], bold: true, shade: true },
      ]);
    }

    // Outflow detail
    if (expenses.length) {
      doc.font('Times-Bold').fontSize(11).text('Outflows (expenses)', M.left);
      doc.moveDown(0.2);
      const w3 = [140, 100, 175, 80];
      tableRows(w3, [
        { cells: ['Event', 'Date', 'Description', 'Amount'], bold: true, shade: true },
        ...expenses.map(x => ({ cells: [x.eventName, toLocalDate(x.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }), x.description, money(x.amount)] })),
      ]);
    }

    const range = doc.bufferedPageRange();
    for (let i = range.start; i < range.start + range.count; i++) {
      doc.switchToPage(i);
      const saved = doc.page.margins.bottom;
      doc.page.margins.bottom = 0;
      doc.font('Times-Roman').fontSize(8.5).fillColor('#555')
        .text(`Page ${i + 1} of ${range.count}`, M.left, A4.height - 40, { width: USABLE, align: 'center', lineBreak: false });
      doc.page.margins.bottom = saved;
    }
    doc.end();
  });
}

module.exports = { buildAnnouncementPdf, buildStatementPdf, buildCountingSheetPdf };
